# angular_with_slim_crud
CRUD using AngularJS with Slim framework.<br>
This is a simple application based on AngularJS and Slim framework.

## Getting Started
<ul>
  <li>Copy the root folder to htdocs or www folder depending on your local server</li>
  <li>Import database file "angular_slim.sql"</li>
  <li>Set the database settings in db.php file</li>
</ul>
You are now ready to start http://localhost/angular_with_slim_crud/index.html
